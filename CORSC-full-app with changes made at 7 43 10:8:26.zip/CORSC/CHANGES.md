# CORSC — medication and storage update

Full application. Drop in place of your working copy, or diff against it.
No new npm dependencies. `package.json` unchanged.

---

## 1. Structured six-column medication entry

Both **medication history** and **medication review** now use the same six
columns, via one shared component (`components/medication-table.jsx`):

| # | Column | Type |
|---|---|---|
| 1 | Drug name | Searchable — selling name, generic composition, misspellings |
| 2 | Dose | Dependent dropdown, only strengths marketed under that brand |
| 3 | Route | PO, SL, PR, inhalation, nebulization, IM, IV, SC (+ ophthalmic, topical, nasal) |
| 4 | Frequency | Named options **or** 1-0-0-1, fractions allowed |
| 5 | Timing | Before / after food, empty stomach, as directed |
| 6 | Remarks | Free text, editable inline |

Catalogue: 287 ingredients, 875 products, 386 brands.

---

## 2. Medication history vs medication review

The two sections now do different jobs, as you described:

- **Medication history** — what the patient has been taking. Adherence and
  allergies retained. Dose-adequacy chips deliberately hidden here, since this
  is a record of the past rather than a prescribing decision.
- **Medication review** — the prescription written at this visit.

### Copy from history

A panel above the prescription shows how many drugs sit in history and how many
are not yet prescribed, with a **Copy from history** button. Each drug carries
across with dose, route, frequency, timing and remarks intact.

Drugs already on the prescription are skipped by brand-plus-dose identity, so
pressing the button twice does nothing the second time. The button disables
itself when nothing is left to copy. Every copied drug is written to
`medicationLog` with the action `copied from history`, so the audit trail shows
what was carried forward rather than newly prescribed.

Free text recorded in the old medication-history box is preserved and shown
read-only beneath the table, with a prompt to re-enter it — never silently
deleted, never silently converted.

---

## 3. Patient storage

### What was already true

Patients **were** being saved. `app/page.jsx` wrote every edit to
`localStorage` on a debounced autosave, and the patient list rendered them.
Nothing was being lost.

### What was actually wrong

- **No ordering.** The list came back in whatever order the browser returned
  keys, so it looked arbitrary and unreliable.
- **No count, no dates.** Nothing confirmed to the clinician that records were
  being kept.
- **Silent quota failure.** A full storage quota set an internal error state
  that was never shown on the list screen. Edits would stop saving with no
  visible warning.
- **No way out.** No export, so data was trapped in one browser profile.

### What changed

- Storage extracted to `lib/patient-storage.js`, with a corrupt single record
  no longer able to hide every other patient.
- List sorted most-recently-updated first; `createdAt` / `updatedAt` stamped on
  every patient and backfilled from `registeredDate` for existing records.
- "All registered patients" header with a live total, plus registered and
  last-updated dates on each card.
- Storage panel showing record count, space used, and an amber warning past 80%.
- Quota and blocked-storage failures now surface as a visible red message.
- **Download backup** produces one JSON file of every patient.
- **Restore from backup** merges by id and keeps whichever copy was updated more
  recently, so restoring an old backup cannot silently undo recent work. The
  result line states what was added, updated and skipped.

### The limitation you should decide about

Records still live in **one browser on one device**. Supabase holds
authentication only. Clearing site data, switching machines, or a browser
eviction under storage pressure loses everything not backed up.

Fixing this properly means syncing patient records to a server — which is a
**PHI and ethics decision, not just an engineering one**, and it bears directly
on the data-flow section of your IEC proposal. I have not implemented it,
because quietly starting to transmit identifiable patient data to Supabase is
not a change that should happen without you deciding it deliberately.

Options worth weighing, roughly in increasing order of work:

1. Keep local-only, mandate a weekly backup as clinic SOP. Zero PHI transmission.
2. Supabase sync with row-level security per clinician, PHI encrypted at rest.
   Requires an IEC amendment describing the flow.
3. Self-hosted database inside the institution's network. Heaviest, but keeps
   PHI within institutional control — usually the easiest ethics argument.

---

## Before clinical use

```bash
node scripts/export-catalog-review.mjs
```

Writes `catalog-review/ingredients.csv` (287 rows) and `products.csv` (875
rows) for pharmacist sign-off. These are my best-effort assertions, not verified
data. Confidence is uneven — cardiovascular, GI and diabetes entries are the
most cross-checked; oncology, dermatology and ophthalmology are thinner.

Two pieces of new clinical logic need your explicit sign-off:

- **Dose adequacy** — shown as *provisional* in the UI. Applies only to ACE
  inhibitor / ARB / ARNI / beta-blocker / MRA.
- **Route-based systemic gating** — timolol eye drops no longer register the
  patient as being on a beta-blocker. Correct for treatment decisions, but
  ophthalmic beta-blockade can still cause systemic bradycardia in susceptible
  patients.

## Deploy

1. `supabase db push` — adds the drug catalogue tables and review queue.
   Without it the hosted lookup is skipped and add-to-library reports the
   service unavailable; the bundled catalogue keeps working offline.
2. Deploy as usual.
