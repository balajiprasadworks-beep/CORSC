"use client";

/* =========================================================================
   Patient list — the entry point into the workflow.

   Shows every patient ever registered on this device for the signed-in user,
   most recently updated first, with the total count stated plainly so it is
   obvious nothing has been lost.

   The storage panel is deliberately visible rather than tucked away: records
   live in this browser only, and a clinician should be able to see that fact
   and take a backup without hunting for a setting.
   ========================================================================= */

import { useRef, useState } from "react";
import { Database, Download, Heart, Plus, Search, TriangleAlert, Upload } from "lucide-react";

import { EmptyState, StatusChip, mono, serif } from "@/components/kit";
import { APP_FULL_NAME, APP_NAME, riskStyle } from "@/lib/clinical-data";

function formatDate(value) {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

function formatSize(bytes) {
  if (!bytes) return "0 KB";
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function StoragePanel({ stats, saveError, onBackup, onRestore }) {
  const fileInput = useRef(null);
  const [restoreResult, setRestoreResult] = useState(null);

  async function handleFile(event) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setRestoreResult(await onRestore(file));
  }

  return (
    <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-3.5">
      <div className="flex items-start gap-2.5">
        <Database size={16} className="mt-0.5 shrink-0 text-slate-400" aria-hidden="true" />
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-semibold text-slate-800">Record storage</div>
          <p className="mt-0.5 text-[12.5px] leading-relaxed text-slate-500">
            {stats.count} patient record{stats.count === 1 ? "" : "s"} saved in this browser
            {stats.supported ? ` · ${formatSize(stats.bytes)} used` : ""}. Records are stored on this
            device only and are not synced to a server — take a backup before clearing browser data
            or moving to another machine.
          </p>

          {stats.nearLimit && (
            <p className="mt-2 flex items-start gap-1.5 rounded-lg bg-amber-50 px-2.5 py-2 text-[12.5px] text-amber-800">
              <TriangleAlert size={14} className="mt-0.5 shrink-0" aria-hidden="true" />
              Storage is about {stats.percentUsed}% full. Download a backup now.
            </p>
          )}

          {saveError && (
            <p className="mt-2 flex items-start gap-1.5 rounded-lg bg-red-50 px-2.5 py-2 text-[12.5px] text-red-700">
              <TriangleAlert size={14} className="mt-0.5 shrink-0" aria-hidden="true" />
              {saveError}
            </p>
          )}

          <div className="mt-2.5 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onBackup}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-[12.5px] font-semibold text-slate-700 transition hover:border-slate-900 hover:text-slate-900"
            >
              <Download size={14} aria-hidden="true" /> Download backup
            </button>
            <button
              type="button"
              onClick={() => fileInput.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-[12.5px] font-semibold text-slate-700 transition hover:border-slate-900 hover:text-slate-900"
            >
              <Upload size={14} aria-hidden="true" /> Restore from backup
            </button>
            <input
              ref={fileInput}
              type="file"
              accept="application/json,.json"
              onChange={handleFile}
              className="hidden"
              aria-hidden="true"
              tabIndex={-1}
            />
          </div>

          {restoreResult && (
            <p
              className={`mt-2 text-[12.5px] ${
                restoreResult.ok ? "text-emerald-700" : "text-red-700"
              }`}
            >
              {restoreResult.reason}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export function PatientList({
  patients,
  onSelect,
  onNew,
  stats = { count: 0, bytes: 0, supported: false },
  saveError = null,
  onBackup = () => {},
  onRestore = async () => ({ ok: false, reason: "Restore is unavailable." }),
}) {
  const [query, setQuery] = useState("");
  const term = query.trim().toLowerCase();
  const filtered = patients.filter(
    (patient) =>
      !term ||
      (patient.name || "").toLowerCase().includes(term) ||
      (patient.patientId || "").toLowerCase().includes(term) ||
      (patient.diagnosis || "").toLowerCase().includes(term),
  );

  return (
    <div className="min-h-screen bg-[#F6F7F5]">
      <div className="bg-gradient-to-br from-[#0B1F3A] to-[#123055] px-4 pb-8 pt-8 text-white">
        <div className="mx-auto max-w-3xl">
          <div className="flex items-center gap-2.5">
            <div className="flex size-10 items-center justify-center rounded-xl bg-teal-500">
              <Heart size={18} className="text-white" fill="white" aria-hidden="true" />
            </div>
            <div>
              <div className="text-[17px] font-bold leading-tight" style={serif}>{APP_NAME}</div>
              <div className="text-[12px] text-white/70">{APP_FULL_NAME}</div>
            </div>
          </div>
          <p className="mt-4 max-w-xl text-[13.5px] leading-relaxed text-white/75">
            HFA-ICOS risk stratification, surveillance planning and outpatient documentation in one
            continuous workflow.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 pb-16">
        <div className="-mt-5 rounded-2xl border border-slate-200 bg-white p-3 shadow-[0_2px_12px_rgba(15,23,42,0.08)]">
          <div className="relative">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search by name, Patient ID or diagnosis"
              aria-label="Search patients"
              className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-[15px] text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20"
            />
          </div>
          <button
            type="button"
            onClick={onNew}
            className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 text-[14px] font-semibold text-white transition hover:bg-slate-800"
          >
            <Plus size={17} aria-hidden="true" /> Register new patient
          </button>
        </div>

        {/* Roster header, so the total is always visible */}
        <div className="mt-5 flex items-baseline justify-between gap-3">
          <h2 className="text-[14px] font-semibold text-slate-800">
            All registered patients
            <span className="ml-2 text-[13px] font-normal text-slate-400">
              {term
                ? `${filtered.length} of ${patients.length}`
                : `${patients.length} total`}
            </span>
          </h2>
        </div>

        <div className="mt-2.5 space-y-2.5">
          {filtered.length === 0 && (
            <EmptyState>
              {patients.length === 0
                ? "No patients registered yet. Register the first patient to begin risk stratification."
                : "No patients match this search."}
            </EmptyState>
          )}

          {filtered.map((patient) => {
            const styles = riskStyle(patient.risk?.category);
            const registered = formatDate(patient.createdAt) || patient.registeredDate || null;
            const updated = formatDate(patient.updatedAt);
            return (
              <button
                key={patient.id}
                type="button"
                onClick={() => onSelect(patient.id)}
                className="w-full rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-teal-300 hover:shadow-[0_2px_10px_rgba(15,23,42,0.07)]"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="truncate text-[15px] font-semibold text-slate-900">
                      {patient.name || "Unnamed patient"}
                    </div>
                    <div className="mt-0.5 truncate text-[13px] text-slate-500">
                      {[patient.diagnosis, patient.stage].filter(Boolean).join(" · ") ||
                        "Diagnosis not recorded"}
                    </div>
                  </div>
                  <span
                    className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold ${styles.bg} ${styles.text}`}
                  >
                    {patient.risk?.category || "Unstratified"}
                  </span>
                </div>
                <div
                  className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-slate-400"
                  style={mono}
                >
                  <span>ID {patient.patientId || "—"}</span>
                  <span>
                    Cycle {patient.cycle ?? 0}
                    {patient.plannedCycles ? `/${patient.plannedCycles}` : ""}
                  </span>
                  <span>
                    {(patient.visits || []).length} encounter
                    {(patient.visits || []).length === 1 ? "" : "s"}
                  </span>
                  <StatusChip
                    tone={
                      patient.clinicalStatus === "Stable" || patient.clinicalStatus === "Improving"
                        ? "ok"
                        : patient.clinicalStatus === "Worsening"
                          ? "warning"
                          : "danger"
                    }
                  >
                    {patient.clinicalStatus}
                  </StatusChip>
                </div>
                {(registered || updated) && (
                  <div className="mt-1.5 flex flex-wrap gap-x-3 text-[11.5px] text-slate-400">
                    {registered && <span>Registered {registered}</span>}
                    {updated && <span>Last updated {updated}</span>}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        <StoragePanel
          stats={stats}
          saveError={saveError}
          onBackup={onBackup}
          onRestore={onRestore}
        />
      </div>
    </div>
  );
}
