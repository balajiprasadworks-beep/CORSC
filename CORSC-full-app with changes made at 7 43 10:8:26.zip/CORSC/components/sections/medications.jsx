"use client";

/* =========================================================================
   Medication review.

   The list is the six structured columns — drug name, dose, route, frequency,
   timing, remarks — rendered as a table on wide screens and as stacked cards
   on a phone, where a six-column table would be unreadable.

   Below the table, the engine reports which cardioprotective therapy is
   indicated at this point in treatment, states the finding that triggered each
   suggestion, and flags QT stacking, duplication, dose adequacy and
   interaction risk.
   ========================================================================= */

import { AlertTriangle, ClipboardCopy, Info, Pill, ShieldCheck } from "lucide-react";

import { Callout, Chip, EmptyState, Panel, Stack, StatusChip, TextArea } from "@/components/kit";
import { MedicationPicker } from "@/components/medication-picker";
import { MedicationTable } from "@/components/medication-table";
import { medClassLabel, resolveMedication } from "@/lib/medication-engine";
import { frequencyText } from "@/lib/medication-schedule";
import { todayISO, uid } from "@/lib/patient-model";

const WARNING_ICON = { danger: AlertTriangle, warning: AlertTriangle, info: Info };

/**
 * Identity used to avoid copying a drug the prescription already carries.
 * Falls back to the typed name for entries with no catalogue match.
 */
function medicationKey(medication) {
  return [
    medication.productId || resolveMedication(medication).displayName.toLowerCase(),
    medication.doseLabel || "",
  ].join("|");
}

export function MedicationSection({ patient, setPatient, encounter, setEncounter, picture }) {
  const medications = patient.medications || [];
  const { recommendations, warnings } = picture;

  function addMedication(medication) {
    setPatient((current) => ({
      ...current,
      medications: [...(current.medications || []), medication],
      medicationLog: [
        ...(current.medicationLog || []),
        {
          id: uid("log"),
          date: encounter.date || todayISO(),
          action: "added",
          name: [medication.displayName, medication.doseLabel].filter(Boolean).join(" "),
          klassLabel: (medication.klasses || []).map(medClassLabel).join(", "),
          schedule: frequencyText(medication.schedule),
        },
      ],
    }));
  }

  function removeMedication(medication) {
    const { displayName, klasses } = resolveMedication(medication);
    setPatient((current) => ({
      ...current,
      medications: (current.medications || []).filter((item) => item.id !== medication.id),
      medicationLog: [
        ...(current.medicationLog || []),
        {
          id: uid("log"),
          date: encounter.date || todayISO(),
          action: "removed",
          name: [displayName, medication.doseLabel].filter(Boolean).join(" "),
          klassLabel: klasses.map(medClassLabel).join(", "),
        },
      ],
    }));
  }

  function setRemarks(medication, remarks) {
    setPatient((current) => ({
      ...current,
      medications: (current.medications || []).map((item) =>
        item.id === medication.id ? { ...item, remarks } : item,
      ),
    }));
  }

  /**
   * Brings the medication history across into this visit's prescription, with
   * dose, route, frequency, timing and remarks intact. Drugs already on the
   * prescription are skipped rather than duplicated, so the button is safe to
   * press twice.
   */
  function copyFromHistory() {
    setPatient((current) => {
      const existing = new Set((current.medications || []).map(medicationKey));
      const incoming = (current.historyMedications || [])
        .filter((medication) => !existing.has(medicationKey(medication)))
        .map((medication) => ({ ...medication, id: uid("m"), copiedFromHistory: true }));
      if (!incoming.length) return current;
      return {
        ...current,
        medications: [...(current.medications || []), ...incoming],
        medicationLog: [
          ...(current.medicationLog || []),
          ...incoming.map((medication) => ({
            id: uid("log"),
            date: encounter.date || todayISO(),
            action: "copied from history",
            name: [medication.displayName, medication.doseLabel].filter(Boolean).join(" "),
            klassLabel: (medication.klasses || []).map(medClassLabel).join(", "),
            schedule: frequencyText(medication.schedule),
          })),
        ],
      };
    });
  }

  function setDecision(recommendationId, decision) {
    setEncounter((current) => ({
      ...current,
      medDecisions: {
        ...current.medDecisions,
        [recommendationId]:
          current.medDecisions?.[recommendationId] === decision ? "" : decision,
      },
    }));
  }

  const historyMedications = patient.historyMedications || [];
  const historyAvailable = historyMedications.length;
  const alreadyPrescribed = new Set(medications.map(medicationKey));
  const notYetCopied = historyMedications.filter(
    (medication) => !alreadyPrescribed.has(medicationKey(medication)),
  ).length;

  const indicated = recommendations.filter((r) => r.strength === "Indicated" && !r.onTreatment);

  return (
    <Stack gap="gap-4">
      {indicated.length > 0 && (
        <Callout
          tone="danger"
          title={`${indicated.length} cardioprotective therap${
            indicated.length === 1 ? "y is" : "ies are"
          } indicated but not prescribed`}
          icon={ShieldCheck}
        >
          {indicated.map((r) => r.title).join(", ")}. Each recommendation below states the finding
          that triggered it.
        </Callout>
      )}

      <Panel
        title="Medication review"
        subtitle="The prescription for this visit — carried forward and reviewed each encounter"
      >
        <Stack>
          {historyAvailable > 0 && (
            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-2.5">
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-medium text-slate-800">
                  {historyAvailable} drug{historyAvailable === 1 ? "" : "s"} recorded in medication
                  history
                </div>
                <div className="text-[12px] text-slate-500">
                  {notYetCopied === 0
                    ? "All already on this prescription."
                    : `${notYetCopied} not yet on this prescription.`}
                </div>
              </div>
              <button
                type="button"
                onClick={copyFromHistory}
                disabled={notYetCopied === 0}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-[12.5px] font-semibold text-slate-800 transition hover:border-slate-900 disabled:border-slate-200 disabled:text-slate-400"
              >
                <ClipboardCopy size={14} aria-hidden="true" /> Copy from history
              </button>
            </div>
          )}

          {medications.length === 0 ? (
            <EmptyState>No medicines on this prescription yet.</EmptyState>
          ) : (
            <MedicationTable
              medications={medications}
              onRemove={removeMedication}
              onRemarks={setRemarks}
            />
          )}
          <MedicationPicker onAdd={addMedication} />
        </Stack>
      </Panel>

      <Panel
        title="Cardioprotective therapy analysis"
        subtitle="Assessed against this patient's therapy, risk category and current findings"
      >
        {recommendations.length === 0 ? (
          <EmptyState>No cardioprotective therapy is triggered by the current findings.</EmptyState>
        ) : (
          <Stack gap="gap-2.5">
            {recommendations.map((recommendation) => {
              const decision = encounter.medDecisions?.[recommendation.id] || "";
              const belowTarget = recommendation.belowTarget || [];
              const toneName = recommendation.onTreatment
                ? belowTarget.length
                  ? "warning"
                  : "ok"
                : recommendation.strength === "Indicated"
                  ? "danger"
                  : "warning";
              return (
                <div
                  key={recommendation.id}
                  className={`rounded-xl border p-3.5 ${
                    recommendation.onTreatment
                      ? belowTarget.length
                        ? "border-amber-200 bg-amber-50/40"
                        : "border-emerald-200 bg-emerald-50/40"
                      : recommendation.strength === "Indicated"
                        ? "border-red-200 bg-red-50/40"
                        : "border-amber-200 bg-amber-50/30"
                  }`}
                >
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[14px] font-semibold text-slate-900">
                        {recommendation.title}
                      </span>
                      <StatusChip tone={toneName}>
                        {recommendation.onTreatment
                          ? belowTarget.length
                            ? "Prescribed, below target"
                            : "Already prescribed"
                          : recommendation.strength}
                      </StatusChip>
                    </div>
                    {recommendation.current && (
                      <span className="text-[12px] text-emerald-700">{recommendation.current}</span>
                    )}
                  </div>

                  {belowTarget.length > 0 && (
                    <div className="mb-2 rounded-lg border border-amber-200 bg-white/70 px-3 py-2">
                      <div className="text-[12px] font-medium uppercase tracking-wide text-amber-700">
                        Dose review (provisional)
                      </div>
                      <ul className="mt-1 space-y-0.5 pl-4 text-[13px] text-slate-700">
                        {belowTarget.map((dose) => (
                          <li key={dose.ingredientId} className="list-disc">
                            {dose.name} at {dose.dailyDose} {dose.unit}/day is {dose.percentOfTarget}%
                            of the {dose.target} {dose.unit} target
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="text-[12.5px] font-medium uppercase tracking-wide text-slate-400">
                    Why this is showing
                  </div>
                  <ul className="mt-1 space-y-1 pl-4 text-[13px] leading-relaxed text-slate-600">
                    {recommendation.reasons.map((reason) => (
                      <li key={reason} className="list-disc">{reason}</li>
                    ))}
                  </ul>

                  <p className="mt-2 text-[13px] leading-relaxed text-slate-700">
                    {recommendation.guidance}
                  </p>

                  {!recommendation.onTreatment && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Chip
                        size="sm"
                        tone="ok"
                        active={decision === "accepted"}
                        onClick={() => setDecision(recommendation.id, "accepted")}
                      >
                        Starting this
                      </Chip>
                      <Chip
                        size="sm"
                        tone="warning"
                        active={decision === "deferred"}
                        onClick={() => setDecision(recommendation.id, "deferred")}
                      >
                        Deferred
                      </Chip>
                      <Chip
                        size="sm"
                        tone="neutral"
                        active={decision === "declined"}
                        onClick={() => setDecision(recommendation.id, "declined")}
                      >
                        Not appropriate
                      </Chip>
                    </div>
                  )}
                </div>
              );
            })}
          </Stack>
        )}
      </Panel>

      <Panel title="Safety review" subtitle="Interaction, duplication, dose and QT screening across the full list">
        {warnings.length === 0 ? (
          <Callout tone="ok" title="No medication safety concerns detected">
            The current list shows no duplicate classes, QT-prolonging combinations, dose concerns or
            interaction risks against this therapy.
          </Callout>
        ) : (
          <Stack gap="gap-2">
            {warnings.map((warning) => {
              const Icon = WARNING_ICON[warning.level] || Info;
              return (
                <Callout key={warning.id} tone={warning.level} title={warning.title} icon={Icon}>
                  <span className="block">{warning.detail}</span>
                  <span className="mt-1 block text-[12px] italic text-slate-500">{warning.why}</span>
                </Callout>
              );
            })}
          </Stack>
        )}
      </Panel>

      <Panel title="Review note">
        <TextArea
          label="Medication review documentation"
          rows={3}
          placeholder="Changes made this visit, counselling given, adherence, monitoring arranged"
          value={encounter.medReview || ""}
          onChange={(value) => setEncounter((current) => ({ ...current, medReview: value }))}
        />
      </Panel>
    </Stack>
  );
}

export const MEDICATION_ICON = Pill;
