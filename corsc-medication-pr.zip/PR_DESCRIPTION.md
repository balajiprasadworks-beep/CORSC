# Add medication catalog, dosing schedule, and clinician-reviewed intake pipeline

## Problem

Typing a brand name the patient actually takes — e.g. **"Rosvas 40"** — wasn't
recognised as a statin, because classification substring-matched typed text
against ~90 hardcoded molecule names. Brand names matched nothing, fell
through to `klass: "other"`, and the app then recommended starting a statin
the patient was already on. The same gap hid combination products entirely:
"Telma AM 40/5" registered as neither an ARB nor a calcium-channel blocker.

## What this PR does

- **Drug catalog** (`lib/drug-catalog.js`) — 287 ingredients / 875 products
  across cardiovascular, dyslipidaemia, hypertension, endocrinology, oncology,
  respiratory, gastrointestinal, neurology, dermatology, ophthalmology and
  supportive care. Combination products resolve to every ingredient they
  contain. Typo-tolerant search.
- **Dosing schedule** (`lib/medication-schedule.js`) — uniform four-slot
  pattern (1-0-0-1 = morning/afternoon/evening/night), food relation,
  frequency, PRN — so every clinician records a dose the same way.
- **Engine rewrite** (`lib/medication-engine.js`) — classification reads
  resolved ingredients instead of typed strings; a medication can carry
  multiple classes; adds dose-adequacy checking against guideline targets.
- **Picker UI** (`components/medication-picker.jsx`) — search, resolve,
  dose. Free text still works for anything not yet catalogued, with an
  explicit clinician confirmation gate before that name is ever sent
  anywhere.
- **Supabase long tail** (`lib/drug-catalog-remote.js`,
  `supabase/migrations/`) — hosted search for the bundled catalog's misses,
  plus a review queue so unmatched drugs get promoted into the catalog after
  clinician sign-off, rather than the catalog staying frozen at this PR.

Scope is deliberately outpatient/everyday medication only — no in-hospital,
emergency, or OT drugs, and no IV infusional chemotherapy (that's tracked via
the existing therapy/regimen field, not this list).

## ⚠️ Before this reaches a real patient

Every ingredient classification, safety flag, and dose target in this PR is
my best-effort assertion from training knowledge, **not verified clinical
data**. `scripts/export-catalog-review.mjs` exports the full catalog to two
CSVs with blank `reviewer_verdict` / `reviewer_comment` columns:

```
node scripts/export-catalog-review.mjs
```

A pharmacist or the responsible clinician needs to sign off on
`catalog-review/ingredients.csv` and `catalog-review/products.csv` before
this is relied on for real prescribing decisions. Confidence is not uniform:
cardiovascular, GI, and diabetes brands are the most cross-checked; oncology,
dermatology, and ophthalmology are newer and thinner — extra scrutiny there.

Dose-adequacy findings render as **provisional** in the UI pending that
review, and only apply to ACE inhibitor / ARB / ARNI / beta-blocker / MRA —
classes with a single defensible guideline-target number.

## Migration

Existing medication records are never silently rewritten. `migrateMedication`
in `lib/patient-model.js` keeps legacy free-text entries exactly as stored,
flags them `needsReview: true`, and attempts a catalog match only at read
time — visible in the UI as "Matched from older record" so a clinician
confirms before relying on the inference.

## Deploy steps

1. Run the migration in `supabase/migrations/20260809_drug_catalog.sql`
   (`supabase db push`) before deploying, or the picker silently skips the
   hosted long tail and free-text sharing reports the service as
   unavailable — it degrades safely either way, bundled catalog keeps
   working offline.
2. No new npm dependencies.

## Testing performed

Reproduced the reported bug and confirmed the fix, then checked: combination
products registering all contained classes, a duplicate hidden inside a
combination pack, sub-target beta-blocker dosing, legacy free-text record
resolution, weekly/alternate-day scheduling, and a new-oncology QT-stacking
case (Kisqali + Emeset) to confirm the expanded categories actually feed the
interaction engine and not just search. All commits in this branch were
generated with `git format-patch` and verified to `git am` cleanly onto a
fresh clone.

## Files changed

```
 .gitignore                                    |    3 +
 components/medication-picker.jsx              |  406 ++++++++++ (new)
 components/sections/medications.jsx           |  206 +++--
 components/sections/overview.jsx              |    9 +-
 lib/drug-catalog-remote.js                    |  107 +++ (new)
 lib/drug-catalog.js                           | 1007 +++++++++++++++++++++++++ (new)
 lib/medication-engine.js                      |  368 +++++++--
 lib/medication-schedule.js                    |  107 +++ (new)
 lib/patient-model.js                          |   27 +-
 scripts/export-catalog-review.mjs             |  104 +++ (new)
 supabase/migrations/20260809_drug_catalog.sql |   98 +++ (new)
 11 files changed, 2294 insertions(+), 148 deletions(-)
```
