"use client";

/* =========================================================================
   Structured medication entry.

   Six columns, one shape for every prescriber:

     1. Drug name   searchable, matches selling name and generic composition
     2. Dose        dependent dropdown, only strengths marketed under that brand
     3. Route       PO / SL / PR / inhalation / nebulisation / IM / IV / SC
     4. Frequency   named (Once daily, SOS) or 1-0-0-1, fractions allowed
     5. Timing      before / after food, empty stomach, as directed
     6. Remarks     free text, the one field intentionally left unstructured

   Anything not in the catalogue can still be entered, together with its
   generic composition, and submitted to the library for review.
   ========================================================================= */

import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronsUpDown, Plus, Search, TriangleAlert } from "lucide-react";

import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox, Field, SelectField, StatusChip, TextArea } from "@/components/kit";
import {
  searchBrands,
  findBrand,
  describeIngredients,
  classesFor,
  defaultRouteFor,
  CATALOG_VERSION,
} from "@/lib/drug-catalog";
import { searchRemoteProducts, submitCatalogRequest } from "@/lib/drug-catalog-remote";
import { MED_CLASSES } from "@/lib/medication-engine";
import {
  SLOTS,
  ROUTE_OPTIONS,
  NAMED_FREQUENCIES,
  CYCLE_OPTIONS,
  TIMING_OPTIONS,
  WEEKDAYS,
  emptySchedule,
  normaliseSchedule,
  patternText,
  unitsPerDose,
  isPrn,
} from "@/lib/medication-schedule";
import { uid } from "@/lib/patient-model";

const triggerClassName =
  "flex min-h-11 w-full items-center justify-between rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-left text-[15px] text-slate-900 shadow-sm outline-none transition focus-visible:border-slate-900 focus-visible:ring-2 focus-visible:ring-slate-900/15";

/* --------------------------------------------------- fractional slot grid */

function SlotGrid({ pattern, onChange }) {
  function setSlot(index, raw) {
    const value = raw === "" ? 0 : Number(raw);
    if (!Number.isFinite(value) || value < 0) return;
    const next = [...pattern];
    next[index] = Math.min(value, 20);
    onChange(next);
  }

  return (
    <div className="grid grid-cols-4 gap-2">
      {SLOTS.map((slot, index) => (
        <div key={slot.key} className="text-center">
          <label
            htmlFor={`slot-${slot.key}`}
            className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-slate-500"
          >
            {slot.label}
          </label>
          <input
            id={`slot-${slot.key}`}
            type="number"
            inputMode="decimal"
            min={0}
            step={0.25}
            value={pattern[index]}
            onChange={(event) => setSlot(index, event.target.value)}
            className={`w-full rounded-xl border px-2 py-2.5 text-center text-[16px] font-semibold outline-none transition focus-visible:ring-2 focus-visible:ring-slate-900/15 ${
              pattern[index] > 0
                ? "border-teal-300 bg-teal-50 text-teal-900"
                : "border-slate-300 bg-white text-slate-400"
            }`}
          />
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------ main picker */

export function MedicationPicker({ onAdd }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [remote, setRemote] = useState([]);
  const [remoteBusy, setRemoteBusy] = useState(false);

  const [brand, setBrand] = useState(null);
  const [strengthId, setStrengthId] = useState("");

  const [newDrug, setNewDrug] = useState(null);
  const [newComposition, setNewComposition] = useState("");
  const [newClass, setNewClass] = useState("");
  const [newDose, setNewDose] = useState("");
  const [shareConfirmed, setShareConfirmed] = useState(false);
  const [shareResult, setShareResult] = useState(null);

  const [schedule, setSchedule] = useState(emptySchedule);
  const [remarks, setRemarks] = useState("");
  const requestId = useRef(0);

  const local = useMemo(() => searchBrands(query, 20), [query]);

  useEffect(() => {
    const term = query.trim();
    if (term.length < 3 || local.length >= 5) {
      setRemote([]);
      setRemoteBusy(false);
      return undefined;
    }
    const ticket = ++requestId.current;
    setRemoteBusy(true);
    const timer = setTimeout(async () => {
      const results = await searchRemoteProducts(term);
      if (ticket === requestId.current) {
        setRemote(results);
        setRemoteBusy(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [query, local.length]);

  const results = useMemo(() => {
    const seen = new Set(local.map((record) => record.key));
    const mapped = remote
      .filter((product) => !seen.has(product.brand.toLowerCase()))
      .map((product) => ({
        key: `remote:${product.id}`,
        brand: product.brand,
        form: product.form,
        composition: describeIngredients(product.ingredients),
        ingredientIds: product.ingredients.map((entry) => entry.id),
        defaultRoute: defaultRouteFor(product.form, product.ingredients),
        remote: true,
        strengths: [
          {
            productId: product.id,
            label: product.strengthLabel,
            display: `${product.strengthLabel} ${product.ingredients[0]?.unit || "mg"}`,
            ingredients: product.ingredients,
            form: product.form,
          },
        ],
      }));
    return [...local, ...mapped];
  }, [local, remote]);

  const strength = brand?.strengths.find((item) => item.productId === strengthId) || null;

  function chooseBrand(record) {
    setBrand(record);
    setStrengthId(record.strengths.length === 1 ? record.strengths[0].productId : "");
    setNewDrug(null);
    setShareResult(null);
    setShareConfirmed(false);
    setSchedule((current) => ({ ...current, route: record.defaultRoute || "po" }));
    setOpen(false);
  }

  function chooseNewDrug() {
    setNewDrug(query.trim());
    setBrand(null);
    setStrengthId("");
    setNewComposition("");
    setNewClass("");
    setNewDose("");
    setShareConfirmed(false);
    setShareResult(null);
    setOpen(false);
  }

  function reset() {
    setBrand(null);
    setStrengthId("");
    setNewDrug(null);
    setNewComposition("");
    setNewClass("");
    setNewDose("");
    setShareConfirmed(false);
    setShareResult(null);
    setQuery("");
    setSchedule(emptySchedule());
    setRemarks("");
  }

  async function shareWithLibrary() {
    const result = await submitCatalogRequest({
      text: newDrug,
      composition: newComposition,
      dose: newDose,
      klass: MED_CLASSES.find((option) => option.label === newClass)?.id || null,
      confirmed: shareConfirmed,
    });
    setShareResult(result);
  }

  function submit() {
    const normalised = normaliseSchedule(schedule);
    if (brand && strength) {
      onAdd({
        id: uid("m"),
        brandKey: brand.remote ? null : brand.key,
        productId: brand.remote ? null : strength.productId,
        displayName: brand.brand,
        name: brand.brand,
        doseLabel: strength.display,
        ingredients: strength.ingredients,
        klasses: classesFor(strength.ingredients),
        klass: classesFor(strength.ingredients)[0] || "other",
        schedule: normalised,
        remarks: remarks.trim(),
        source: "catalog",
        catalogVersion: CATALOG_VERSION,
      });
    } else if (newDrug) {
      const klassId = MED_CLASSES.find((option) => option.label === newClass)?.id || "other";
      onAdd({
        id: uid("m"),
        brandKey: null,
        productId: null,
        displayName: newDrug,
        name: newDrug,
        doseLabel: newDose.trim(),
        composition: newComposition.trim(),
        ingredients: [],
        klasses: [klassId],
        klass: klassId,
        schedule: normalised,
        remarks: remarks.trim(),
        source: "freetext",
        catalogVersion: CATALOG_VERSION,
      });
    }
    reset();
  }

  const hasDrug = Boolean((brand && strength) || newDrug);
  const scheduleSet = unitsPerDose(schedule) > 0 || isPrn(schedule);
  const ready = hasDrug && scheduleSet;

  return (
    <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-3">
      {/* Column 1 — drug name */}
      <Field label="Drug name" hint="Search by selling name or generic composition.">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger className={triggerClassName} aria-label="Search and select a drug">
            <span className={brand || newDrug ? "truncate" : "text-slate-400"}>
              {brand?.brand || newDrug || "Search and select a drug"}
            </span>
            <ChevronsUpDown className="ml-3 size-4 shrink-0 text-slate-500" aria-hidden="true" />
          </PopoverTrigger>
          <PopoverContent align="start" className="w-[min(32rem,calc(100vw-2rem))] p-1">
            <Command shouldFilter={false}>
              <CommandInput
                placeholder="Type a selling name or molecule"
                value={query}
                onValueChange={setQuery}
              />
              <CommandList>
                {results.length === 0 && query.trim().length > 0 && (
                  <CommandEmpty className="px-3 py-4 text-[13px] text-slate-500">
                    {remoteBusy ? (
                      "Checking the hosted library…"
                    ) : (
                      <button
                        type="button"
                        onClick={chooseNewDrug}
                        className="text-left font-medium text-slate-900 underline"
                      >
                        Not in the library — add “{query.trim()}”
                      </button>
                    )}
                  </CommandEmpty>
                )}
                {results.length === 0 && !query.trim() && (
                  <div className="flex items-center gap-2 px-3 py-4 text-[13px] text-slate-500">
                    <Search size={14} aria-hidden="true" /> Start typing to search the library.
                  </div>
                )}
                {results.length > 0 && (
                  <CommandGroup>
                    {results.map((record) => (
                      <CommandItem key={record.key} value={record.key} onSelect={() => chooseBrand(record)}>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="truncate text-[13.5px] font-semibold text-slate-900">
                              {record.brand}
                            </span>
                            {record.remote && <StatusChip tone="neutral">Hosted</StatusChip>}
                            {!record.remote && record.strengths.length > 1 && (
                              <span className="shrink-0 text-[11px] text-slate-400">
                                {record.strengths.length} strengths
                              </span>
                            )}
                          </div>
                          <div className="truncate text-[12px] text-slate-500">{record.composition}</div>
                        </div>
                        {brand?.key === record.key && (
                          <Check className="size-4 text-teal-600" aria-hidden="true" />
                        )}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                )}
                {results.length > 0 && query.trim() && (
                  <div className="border-t border-slate-100 px-3 py-2">
                    <button
                      type="button"
                      onClick={chooseNewDrug}
                      className="text-[12.5px] text-slate-500 underline"
                    >
                      None of these — add “{query.trim()}” to the library
                    </button>
                  </div>
                )}
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </Field>

      {/* Column 2 — dose, dependent on the selected drug */}
      {brand && (
        <div className="mt-3">
          <SelectField
            label="Dose"
            value={strength?.display || ""}
            onChange={(display) => {
              const match = brand.strengths.find((item) => item.display === display);
              setStrengthId(match?.productId || "");
            }}
            options={brand.strengths.map((item) => item.display)}
            placeholder="Select the strength"
          />
          {strength && (
            <div className="mt-2 rounded-lg border border-teal-200 bg-teal-50/50 px-3 py-2">
              <div className="text-[12px] font-medium uppercase tracking-wide text-teal-700">
                Generic composition
              </div>
              <div className="mt-0.5 text-[13px] text-slate-700">
                {describeIngredients(strength.ingredients)}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Add-to-library panel */}
      {newDrug && (
        <div className="mt-3 space-y-3 rounded-lg border border-amber-200 bg-amber-50/50 px-3 py-2.5">
          <div className="flex items-start gap-2">
            <TriangleAlert size={15} className="mt-0.5 shrink-0 text-amber-600" aria-hidden="true" />
            <p className="text-[12.5px] leading-relaxed text-amber-800">
              This drug is not in the library. Record its generic composition so the entry is still
              clinically meaningful, and it can be added to the library for everyone after review.
            </p>
          </div>

          <Field label="Dose" hint="Type the strength, for example 40 mg.">
            <input
              type="text"
              value={newDose}
              onChange={(event) => setNewDose(event.target.value)}
              placeholder="e.g. 40 mg"
              className="min-h-11 w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-[15px] outline-none focus-visible:border-slate-900 focus-visible:ring-2 focus-visible:ring-slate-900/15"
            />
          </Field>

          <Field
            label="Generic composition"
            hint="For example: Telmisartan 40 mg + Amlodipine 5 mg."
          >
            <input
              type="text"
              value={newComposition}
              onChange={(event) => setNewComposition(event.target.value)}
              placeholder="Molecule names and strengths"
              className="min-h-11 w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-[15px] outline-none focus-visible:border-slate-900 focus-visible:ring-2 focus-visible:ring-slate-900/15"
            />
          </Field>

          <SelectField
            label="Class"
            value={newClass}
            onChange={setNewClass}
            options={MED_CLASSES.map((option) => option.label)}
            placeholder="Select class"
            hint="Choosing a class restores duplicate-therapy checking for this entry."
          />

          <div className="border-t border-amber-200 pt-2.5">
            <Checkbox
              checked={shareConfirmed}
              onChange={() => {
                setShareConfirmed((value) => !value);
                setShareResult(null);
              }}
              label="Add this drug to the shared library"
              hint="Confirms the name and composition above contain no patient identifiers. Only those fields and the class are sent for review."
            />
            {shareConfirmed && !shareResult && (
              <button
                type="button"
                onClick={shareWithLibrary}
                className="mt-2 rounded-lg border border-amber-300 bg-white px-3 py-1.5 text-[12.5px] font-semibold text-amber-800 transition hover:bg-amber-100"
              >
                Submit for review
              </button>
            )}
            {shareResult && (
              <p className={`mt-2 text-[12.5px] ${shareResult.ok ? "text-emerald-700" : "text-slate-600"}`}>
                {shareResult.ok
                  ? "Submitted for review. The drug is saved to this patient either way."
                  : shareResult.reason}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Columns 3 to 6 */}
      {hasDrug && (
        <div className="mt-3 space-y-3">
          <SelectField
            label="Route"
            value={ROUTE_OPTIONS.find((option) => option.id === schedule.route)?.label}
            onChange={(label) =>
              setSchedule((current) => ({
                ...current,
                route: ROUTE_OPTIONS.find((option) => option.label === label)?.id || "po",
              }))
            }
            options={ROUTE_OPTIONS.map((option) => option.label)}
          />

          <Field label="Frequency">
            <div className="mb-2 flex gap-1.5">
              <button
                type="button"
                onClick={() => setSchedule((current) => ({ ...current, frequencyMode: "named" }))}
                className={`rounded-lg border px-2.5 py-1 text-[12px] font-medium transition ${
                  schedule.frequencyMode === "named"
                    ? "border-slate-900 bg-slate-900 text-white"
                    : "border-slate-300 bg-white text-slate-600"
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => setSchedule((current) => ({ ...current, frequencyMode: "pattern" }))}
                className={`rounded-lg border px-2.5 py-1 text-[12px] font-medium transition ${
                  schedule.frequencyMode === "pattern"
                    ? "border-slate-900 bg-slate-900 text-white"
                    : "border-slate-300 bg-white text-slate-600"
                }`}
              >
                1-0-0-1 format
              </button>
            </div>

            {schedule.frequencyMode === "named" ? (
              <SelectField
                label=""
                value={NAMED_FREQUENCIES.find((option) => option.id === schedule.named)?.label}
                onChange={(label) =>
                  setSchedule((current) => ({
                    ...current,
                    named: NAMED_FREQUENCIES.find((option) => option.label === label)?.id || "od",
                  }))
                }
                options={NAMED_FREQUENCIES.map((option) => option.label)}
              />
            ) : (
              <div className="space-y-2">
                <SlotGrid
                  pattern={schedule.pattern}
                  onChange={(pattern) => setSchedule((current) => ({ ...current, pattern }))}
                />
                <p className="text-[12px] text-slate-500">
                  Recorded as {patternText(schedule)}. Use decimals for part tablets — 0.5 for half,
                  2 for two.
                </p>
              </div>
            )}
          </Field>

          <div className="grid gap-3 sm:grid-cols-2">
            <SelectField
              label="Repeats"
              value={CYCLE_OPTIONS.find((option) => option.id === schedule.cycle)?.label}
              onChange={(label) =>
                setSchedule((current) => ({
                  ...current,
                  cycle: CYCLE_OPTIONS.find((option) => option.label === label)?.id || "daily",
                }))
              }
              options={CYCLE_OPTIONS.map((option) => option.label)}
            />
            {schedule.cycle === "weekly" && (
              <SelectField
                label="Day of the week"
                value={schedule.weekday || ""}
                onChange={(weekday) => setSchedule((current) => ({ ...current, weekday }))}
                options={WEEKDAYS}
                placeholder="Select day"
              />
            )}
          </div>

          <SelectField
            label="Timing"
            value={TIMING_OPTIONS.find((option) => option.id === schedule.timing)?.label}
            onChange={(label) =>
              setSchedule((current) => ({
                ...current,
                timing: TIMING_OPTIONS.find((option) => option.label === label)?.id || "after",
              }))
            }
            options={TIMING_OPTIONS.map((option) => option.label)}
          />

          <TextArea
            label="Remarks"
            rows={2}
            placeholder="Any instruction or note for this drug"
            value={remarks}
            onChange={setRemarks}
          />
        </div>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={submit}
          disabled={!ready}
          className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-[13px] font-semibold text-white transition hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-400"
        >
          <Plus size={14} aria-hidden="true" /> Add to list
        </button>
        {(brand || newDrug) && (
          <button type="button" onClick={reset} className="text-[12.5px] text-slate-500 underline">
            Clear
          </button>
        )}
        {brand && !strength && (
          <span className="text-[12px] text-slate-500">Select a dose to continue.</span>
        )}
        {hasDrug && !scheduleSet && (
          <span className="text-[12px] text-slate-500">Set a frequency, or choose SOS.</span>
        )}
      </div>
    </div>
  );
}
