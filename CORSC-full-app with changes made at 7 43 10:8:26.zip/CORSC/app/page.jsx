"use client";

/* =========================================================================
   CORSC — Cardiac Oncology Risk Surveillance and Care

   Application shell: authentication, patient storage with continuous autosave,
   and routing between the patient list, registration, and the encounter
   workflow. All clinical rendering lives in the workflow sections.
   ========================================================================= */

import { useCallback, useEffect, useRef, useState } from "react";
import { LogOut } from "lucide-react";

import { AuthGate } from "@/components/auth-gate";
import { PatientList } from "@/components/patient-list";
import { PatientWorkflow } from "@/components/patient-workflow";
import { RegisterPatient } from "@/components/register-patient";
import { Button } from "@/components/ui/button";
import { createEncounter, migratePatient } from "@/lib/patient-model";
import {
  loadPatients,
  savePatient,
  sortPatients,
  storageStats,
  downloadBackup,
  parseBackup,
  mergeRestored,
} from "@/lib/patient-storage";

const AUTOSAVE_DELAY = 600;

function CORSCWorkspace({ user, onSignOut }) {
  const [patients, setPatients] = useState(() => loadPatients(user.id, migratePatient));
  const [view, setView] = useState("list");
  const [selectedId, setSelectedId] = useState(null);
  const [saveState, setSaveState] = useState("saved");
  const [saveError, setSaveError] = useState(null);
  const [stats, setStats] = useState(() => storageStats(user.id));
  const pending = useRef(new Map());
  const timer = useRef(null);

  /* Debounced autosave — every edit lands in local storage without a save button. */
  const schedulePersist = useCallback(
    (patient) => {
      pending.current.set(patient.id, patient);
      setSaveState("saving");
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => {
        let failure = null;
        pending.current.forEach((record) => {
          const result = savePatient(user.id, record);
          if (!result.ok) failure = result;
        });
        if (failure) {
          /* Keep the queue so a later attempt, or a freed quota, can retry. */
          setSaveState("error");
          setSaveError(
            failure.reason === "quota"
              ? "This browser's storage is full. Download a backup and remove old patients, or recent edits will not be saved."
              : "This browser blocked local storage, so recent edits are not saved.",
          );
        } else {
          pending.current.clear();
          setSaveState("saved");
          setSaveError(null);
          setStats(storageStats(user.id));
        }
      }, AUTOSAVE_DELAY);
    },
    [user.id]
  );

  useEffect(() => () => timer.current && clearTimeout(timer.current), []);

  const updatePatient = useCallback(
    (updater) => {
      setPatients((current) => {
        const index = current.findIndex((patient) => patient.id === selectedId);
        if (index < 0) return current;
        const draft = typeof updater === "function" ? updater(current[index]) : { ...current[index], ...updater };
        const next = { ...draft, updatedAt: new Date().toISOString() };
        schedulePersist(next);
        return current.map((patient, i) => (i === index ? next : patient));
      });
    },
    [selectedId, schedulePersist]
  );

  function createPatientRecord(patient) {
    setPatients((current) => sortPatients([patient, ...current]));
    schedulePersist(patient);
    setSelectedId(patient.id);
    setView("workflow");
  }

  function handleBackup() {
    downloadBackup(user.id, patients);
  }

  async function handleRestore(file) {
    const text = await file.text();
    const parsed = parseBackup(text);
    if (!parsed.ok) return parsed;

    const migrated = parsed.patients.map(migratePatient).filter(Boolean);
    const merged = mergeRestored(patients, migrated);
    setPatients(merged.patients);
    merged.patients.forEach((patient) => savePatient(user.id, patient));
    setStats(storageStats(user.id));
    return {
      ok: true,
      reason: `Restored ${merged.added} new and ${merged.updated} updated patient${
        merged.updated === 1 ? "" : "s"
      }. ${merged.skipped} local record${merged.skipped === 1 ? " was" : "s were"} already newer and left untouched.`,
    };
  }

  function openPatient(id) {
    setPatients((current) =>
      current.map((patient) =>
        patient.id === id && !patient.draftEncounter
          ? { ...patient, draftEncounter: createEncounter(patient.visits?.length ? `Cycle ${(Number(patient.cycle) || 0) + 1}` : "Baseline") }
          : patient
      )
    );
    setSelectedId(id);
    setView("workflow");
  }

  const selected = patients.find((patient) => patient.id === selectedId);

  return (
    <div className="min-h-screen bg-[#F6F7F5]">
      {view !== "workflow" && (
        <div className="no-print mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 pt-3">
          <span className="truncate text-xs text-slate-500">{user.email || "Signed in"}</span>
          <Button type="button" variant="outline" size="sm" className="shrink-0" onClick={onSignOut}>
            <LogOut className="size-3.5" aria-hidden="true" />
            Sign out
          </Button>
        </div>
      )}

      {view === "list" ? (
        <PatientList
          patients={patients}
          onSelect={openPatient}
          onNew={() => setView("register")}
          stats={stats}
          saveError={saveError}
          onBackup={handleBackup}
          onRestore={handleRestore}
        />
      ) : view === "register" ? (
        <RegisterPatient onCancel={() => setView("list")} onCreate={createPatientRecord} />
      ) : selected ? (
        <PatientWorkflow
          patient={selected}
          setPatient={updatePatient}
          saveState={saveState}
          onBack={() => setView("list")}
        />
      ) : (
        <div className="p-16 text-center text-sm text-slate-400">Patient not found.</div>
      )}
    </div>
  );
}

export default function CORSCApp() {
  return (
    <AuthGate>
      {({ user, signOut }) => <CORSCWorkspace key={user.id} user={user} onSignOut={signOut} />}
    </AuthGate>
  );
}
