/* =========================================================================
   Exports every clinical assertion held in the drug catalogue to CSV, so a
   pharmacist or the responsible clinician can sign it off before the catalogue
   is used in patient care.

   Run:  node scripts/export-catalog-review.mjs
   Out:  catalog-review/ingredients.csv
         catalog-review/products.csv
   ========================================================================= */

import { mkdirSync, writeFileSync } from "node:fs";
import { INGREDIENTS, PRODUCTS, CATALOG_VERSION, describeIngredients } from "../lib/drug-catalog.js";

function csvCell(value) {
  const text = value === null || value === undefined ? "" : String(value);
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function toCsv(headers, rows) {
  return [headers, ...rows].map((row) => row.map(csvCell).join(",")).join("\n");
}

mkdirSync("catalog-review", { recursive: true });

/* --- Ingredients: class, safety flags and dose bands --- */

const ingredientRows = Object.values(INGREDIENTS)
  .sort((a, b) => a.klass.localeCompare(b.klass) || a.name.localeCompare(b.name))
  .map((item) => [
    item.id,
    item.name,
    item.klass,
    item.qt ? "YES" : "",
    item.cyp3a4 ? "YES" : "",
    item.renal ? "YES" : "",
    item.dose ? item.dose[0] : "",
    item.dose ? item.dose[1] : "",
    item.dose ? item.dose[2] : "",
    item.dose ? item.dose[3] : "",
    item.note || "",
    "", // Reviewer verdict
    "", // Reviewer comment
  ]);

writeFileSync(
  "catalog-review/ingredients.csv",
  toCsv(
    [
      "ingredient_id",
      "name",
      "class",
      "qt_risk",
      "cyp3a4_inhibitor",
      "renal_adjust",
      "dose_start",
      "dose_target",
      "dose_max",
      "dose_unit",
      "note",
      "reviewer_verdict",
      "reviewer_comment",
    ],
    ingredientRows,
  ),
);

/* --- Products: brand-to-ingredient mapping --- */

const productRows = PRODUCTS.sort((a, b) => a.brand.localeCompare(b.brand) || a.label.localeCompare(b.label)).map(
  (product) => [
    product.id,
    product.brand,
    product.strengthLabel,
    describeIngredients(product.ingredients),
    product.ingredients.length > 1 ? "COMBINATION" : "",
    product.form,
    product.aliases.join("; "),
    "", // Reviewer verdict
    "", // Reviewer comment
  ],
);

writeFileSync(
  "catalog-review/products.csv",
  toCsv(
    [
      "product_id",
      "brand",
      "strength",
      "resolved_ingredients",
      "combination",
      "form",
      "aliases",
      "reviewer_verdict",
      "reviewer_comment",
    ],
    productRows,
  ),
);

console.log(`Catalogue ${CATALOG_VERSION}`);
console.log(`  ingredients.csv  ${ingredientRows.length} rows`);
console.log(`  products.csv     ${productRows.length} rows`);
console.log("Leave reviewer_verdict blank to accept, or write REJECT / AMEND with a comment.");
