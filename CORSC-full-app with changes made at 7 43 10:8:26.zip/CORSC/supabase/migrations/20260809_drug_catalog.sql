-- =========================================================================
-- Drug catalogue: hosted long tail plus the review queue.
--
-- The bundled catalogue in lib/drug-catalog.js covers cardiovascular therapy
-- and common comorbidity prescribing. This schema holds everything beyond it.
--
-- Neither table holds patient data. `drug_products` is reference data.
-- `drug_catalog_requests` stores a medicine name the clinician has explicitly
-- confirmed contains no patient identifiers, together with a suggested class.
-- =========================================================================

create extension if not exists pg_trgm;

-- ------------------------------------------------------------- products ---

create table if not exists public.drug_products (
  id             uuid primary key default gen_random_uuid(),
  brand          text not null,
  strength_label text,
  ingredients    jsonb not null default '[]'::jsonb,
  aliases        text[] not null default '{}',
  form           text not null default 'tablet',
  source         text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),

  -- Generated haystack so search stays a single indexed column.
  search_text    tsvector generated always as (
    to_tsvector(
      'simple',
      coalesce(brand, '') || ' ' ||
      coalesce(strength_label, '') || ' ' ||
      coalesce(array_to_string(aliases, ' '), '') || ' ' ||
      coalesce(jsonb_path_query_array(ingredients, '$[*].id')::text, '')
    )
  ) stored
);

create index if not exists drug_products_search_idx on public.drug_products using gin (search_text);
create index if not exists drug_products_brand_trgm_idx on public.drug_products using gin (brand gin_trgm_ops);
create unique index if not exists drug_products_brand_strength_idx
  on public.drug_products (lower(brand), lower(coalesce(strength_label, '')));

alter table public.drug_products enable row level security;

-- Reference data: any signed-in clinician may read, nobody may write from the client.
create policy "drug_products_read"
  on public.drug_products for select
  to authenticated
  using (true);

-- ------------------------------------------------------- review requests ---

create table if not exists public.drug_catalog_requests (
  id              uuid primary key default gen_random_uuid(),
  submitted_text  text not null check (char_length(submitted_text) between 1 and 200),
  composition     text check (composition is null or char_length(composition) <= 300),
  dose            text check (dose is null or char_length(dose) <= 60),
  suggested_class text,
  note            text check (note is null or char_length(note) <= 500),
  status          text not null default 'pending'
                    check (status in ('pending', 'accepted', 'rejected', 'duplicate')),
  submitted_by    uuid default auth.uid(),
  created_at      timestamptz not null default now(),
  reviewed_at     timestamptz,
  reviewer_note   text
);

create index if not exists drug_catalog_requests_status_idx
  on public.drug_catalog_requests (status, created_at desc);

alter table public.drug_catalog_requests enable row level security;

-- Clinicians may submit, and may read back only what they submitted.
create policy "drug_catalog_requests_insert"
  on public.drug_catalog_requests for insert
  to authenticated
  with check (submitted_by = auth.uid());

create policy "drug_catalog_requests_read_own"
  on public.drug_catalog_requests for select
  to authenticated
  using (submitted_by = auth.uid());

-- ----------------------------------------------------------- maintenance ---

create or replace function public.touch_drug_products()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists drug_products_touch on public.drug_products;
create trigger drug_products_touch
  before update on public.drug_products
  for each row execute function public.touch_drug_products();
