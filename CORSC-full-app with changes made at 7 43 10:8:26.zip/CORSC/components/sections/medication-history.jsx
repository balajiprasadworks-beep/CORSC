"use client";

/* =========================================================================
   Medication history.

   The drugs the patient has been taking up to this visit, recorded in the same
   six columns as the prescription so the two can be compared — and copied —
   without retyping.

   Allergies and adherence stay here as the clinical questions they always
   were. Anything captured as free text before structured entry existed is
   shown read-only rather than discarded.
   ========================================================================= */

import { History } from "lucide-react";

import { Callout, EmptyState, SelectField, Stack, TextField } from "@/components/kit";
import { MedicationPicker } from "@/components/medication-picker";
import { MedicationTable } from "@/components/medication-table";
import { uid } from "@/lib/patient-model";

const ADHERENCE_OPTIONS = ["Good", "Partial", "Poor", "Not assessed"];

export function MedicationHistoryPanel({ patient, setPatient }) {
  const medications = patient.historyMedications || [];
  const fields = patient.history?.medication?.fields || {};
  const legacy = String(fields.current || "").trim();

  function updateField(key, value) {
    setPatient((current) => {
      const history = current.history || {};
      const group = history.medication || { checks: {}, fields: {} };
      return {
        ...current,
        history: {
          ...history,
          medication: { ...group, fields: { ...group.fields, [key]: value } },
        },
      };
    });
  }

  function addMedication(medication) {
    setPatient((current) => ({
      ...current,
      historyMedications: [...(current.historyMedications || []), { ...medication, id: uid("hm") }],
    }));
  }

  function removeMedication(medication) {
    setPatient((current) => ({
      ...current,
      historyMedications: (current.historyMedications || []).filter((item) => item.id !== medication.id),
    }));
  }

  function setRemarks(medication, remarks) {
    setPatient((current) => ({
      ...current,
      historyMedications: (current.historyMedications || []).map((item) =>
        item.id === medication.id ? { ...item, remarks } : item,
      ),
    }));
  }

  return (
    <Stack>
      {medications.length === 0 ? (
        <EmptyState>
          No past medication recorded yet. Add each drug the patient is already taking.
        </EmptyState>
      ) : (
        <MedicationTable
          medications={medications}
          onRemove={removeMedication}
          onRemarks={setRemarks}
          showDoseAdequacy={false}
        />
      )}

      <MedicationPicker onAdd={addMedication} />

      {legacy && (
        <Callout tone="info" title="Recorded before structured entry">
          <span className="whitespace-pre-line">{legacy}</span>
          <span className="mt-1 block text-[12px] italic text-slate-500">
            Kept as originally typed. Re-enter these above to bring them into interaction and
            duplication checking.
          </span>
        </Callout>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        <TextField
          label="Allergies / intolerances"
          placeholder="e.g. ACE inhibitor cough"
          value={fields.allergies || ""}
          onChange={(value) => updateField("allergies", value)}
        />
        <SelectField
          label="Adherence"
          options={ADHERENCE_OPTIONS}
          value={fields.adherence || ""}
          onChange={(value) => updateField("adherence", value)}
        />
      </div>
    </Stack>
  );
}

export const MEDICATION_HISTORY_ICON = History;
