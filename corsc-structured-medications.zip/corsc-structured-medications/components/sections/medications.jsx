"use client";

/* =========================================================================
   Medication review.

   The list is the six structured columns — drug name, dose, route, frequency,
   timing, remarks — rendered as a table on wide screens and as stacked cards
   on a phone, where a six-column table would be unreadable.

   Below the table, the engine reports which cardioprotective therapy is
   indicated at this point in treatment, states the finding that triggered each
   suggestion, and flags QT stacking, duplication, dose adequacy and
   interaction risk.
   ========================================================================= */

import { AlertTriangle, Info, Pill, ShieldCheck, Trash2 } from "lucide-react";

import { Callout, Chip, EmptyState, Panel, Stack, StatusChip, TextArea, mono } from "@/components/kit";
import { MedicationPicker } from "@/components/medication-picker";
import { assessDose, medClassLabel, resolveMedication } from "@/lib/medication-engine";
import { describeIngredients } from "@/lib/drug-catalog";
import {
  frequencyText,
  routeLabel,
  timingLabel,
  normaliseSchedule,
  isSystemicRoute,
  isScheduleEmpty,
} from "@/lib/medication-schedule";
import { todayISO, uid } from "@/lib/patient-model";

const WARNING_ICON = { danger: AlertTriangle, warning: AlertTriangle, info: Info };

const DOSE_TONE = {
  atTarget: { tone: "ok", text: "At target" },
  belowTarget: { tone: "warning", text: "Below target" },
  aboveMax: { tone: "danger", text: "Above maximum" },
};

const COLUMNS = ["Drug name", "Dose", "Route", "Frequency", "Timing", "Remarks", ""];

/** Everything the row and card views both need, derived once. */
function useRowData(medication) {
  const { ingredients, klasses, displayName, resolved, inferred } = resolveMedication(medication);
  const schedule = normaliseSchedule(medication.schedule);
  return {
    ingredients,
    klasses,
    displayName,
    resolved,
    inferred,
    schedule,
    doses: assessDose(medication).filter((dose) => dose.status !== "unknown"),
    composition: ingredients.length ? describeIngredients(ingredients) : medication.composition || "",
    nonSystemic: !isSystemicRoute(schedule.route),
  };
}

function DoseChips({ doses }) {
  if (!doses.length) return null;
  return (
    <div className="mt-1 flex flex-wrap gap-1">
      {doses.map((dose) => {
        const label = DOSE_TONE[dose.status];
        if (!label) return null;
        return (
          <StatusChip key={dose.ingredientId} tone={label.tone}>
            {dose.name} {dose.dailyDose} {dose.unit}/day — {label.text}
            {dose.status === "belowTarget" && dose.percentOfTarget !== null
              ? ` (${dose.percentOfTarget}%)`
              : ""}
          </StatusChip>
        );
      })}
    </div>
  );
}

function NameCell({ data }) {
  return (
    <div className="min-w-0">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-[13.5px] font-semibold text-slate-900">{data.displayName}</span>
        {!data.resolved && <StatusChip tone="warning">Unmatched</StatusChip>}
        {data.inferred && <StatusChip tone="warning">Matched from older record</StatusChip>}
      </div>
      {data.composition && <div className="mt-0.5 text-[12px] text-slate-500">{data.composition}</div>}
      <div className="mt-1 flex flex-wrap gap-1">
        {data.klasses.map((klass) => (
          <StatusChip key={klass} tone="neutral">{medClassLabel(klass)}</StatusChip>
        ))}
        {data.nonSystemic && <StatusChip tone="neutral">Not systemic</StatusChip>}
      </div>
    </div>
  );
}

function MedicationCard({ medication, onRemove, onRemarks }) {
  const data = useRowData(medication);
  return (
    <div className="rounded-lg border border-slate-200 px-3 py-2.5">
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          <NameCell data={data} />
          <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[12.5px]">
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Dose</dt>
              <dd className="text-slate-700">{medication.doseLabel || "—"}</dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Route</dt>
              <dd className="text-slate-700">{routeLabel(data.schedule.route)}</dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Frequency</dt>
              <dd className="text-slate-700" style={mono}>
                {isScheduleEmpty(medication.schedule) ? "—" : frequencyText(data.schedule)}
              </dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Timing</dt>
              <dd className="text-slate-700">{timingLabel(data.schedule.timing)}</dd>
            </div>
          </dl>
          <DoseChips doses={data.doses} />
          <TextArea
            label="Remarks"
            rows={1}
            placeholder="Add a note"
            value={medication.remarks || ""}
            onChange={(value) => onRemarks(medication, value)}
          />
        </div>
        <button
          type="button"
          onClick={() => onRemove(medication)}
          aria-label={`Remove ${data.displayName}`}
          className="shrink-0 rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
        >
          <Trash2 size={15} aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

function MedicationRow({ medication, onRemove, onRemarks }) {
  const data = useRowData(medication);
  return (
    <tr className="border-b border-slate-100 align-top last:border-b-0">
      <td className="px-3 py-2.5">
        <NameCell data={data} />
        <DoseChips doses={data.doses} />
      </td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700">{medication.doseLabel || "—"}</td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700">{routeLabel(data.schedule.route)}</td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700" style={mono}>
        {isScheduleEmpty(medication.schedule) ? "—" : frequencyText(data.schedule)}
      </td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700">{timingLabel(data.schedule.timing)}</td>
      <td className="px-3 py-2.5">
        <TextArea
          label=""
          rows={2}
          placeholder="Add a note"
          value={medication.remarks || ""}
          onChange={(value) => onRemarks(medication, value)}
        />
      </td>
      <td className="px-2 py-2.5">
        <button
          type="button"
          onClick={() => onRemove(medication)}
          aria-label={`Remove ${data.displayName}`}
          className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
        >
          <Trash2 size={15} aria-hidden="true" />
        </button>
      </td>
    </tr>
  );
}

export function MedicationSection({ patient, setPatient, encounter, setEncounter, picture }) {
  const medications = patient.medications || [];
  const { recommendations, warnings } = picture;

  function addMedication(medication) {
    setPatient((current) => ({
      ...current,
      medications: [...(current.medications || []), medication],
      medicationLog: [
        ...(current.medicationLog || []),
        {
          id: uid("log"),
          date: encounter.date || todayISO(),
          action: "added",
          name: [medication.displayName, medication.doseLabel].filter(Boolean).join(" "),
          klassLabel: (medication.klasses || []).map(medClassLabel).join(", "),
          schedule: frequencyText(medication.schedule),
        },
      ],
    }));
  }

  function removeMedication(medication) {
    const { displayName, klasses } = resolveMedication(medication);
    setPatient((current) => ({
      ...current,
      medications: (current.medications || []).filter((item) => item.id !== medication.id),
      medicationLog: [
        ...(current.medicationLog || []),
        {
          id: uid("log"),
          date: encounter.date || todayISO(),
          action: "removed",
          name: [displayName, medication.doseLabel].filter(Boolean).join(" "),
          klassLabel: klasses.map(medClassLabel).join(", "),
        },
      ],
    }));
  }

  function setRemarks(medication, remarks) {
    setPatient((current) => ({
      ...current,
      medications: (current.medications || []).map((item) =>
        item.id === medication.id ? { ...item, remarks } : item,
      ),
    }));
  }

  function setDecision(recommendationId, decision) {
    setEncounter((current) => ({
      ...current,
      medDecisions: {
        ...current.medDecisions,
        [recommendationId]:
          current.medDecisions?.[recommendationId] === decision ? "" : decision,
      },
    }));
  }

  const indicated = recommendations.filter((r) => r.strength === "Indicated" && !r.onTreatment);

  return (
    <Stack gap="gap-4">
      {indicated.length > 0 && (
        <Callout
          tone="danger"
          title={`${indicated.length} cardioprotective therap${
            indicated.length === 1 ? "y is" : "ies are"
          } indicated but not prescribed`}
          icon={ShieldCheck}
        >
          {indicated.map((r) => r.title).join(", ")}. Each recommendation below states the finding
          that triggered it.
        </Callout>
      )}

      <Panel title="Current medication" subtitle="Carried forward between visits and reviewed each encounter">
        <Stack>
          {medications.length === 0 ? (
            <EmptyState>No medicines recorded yet.</EmptyState>
          ) : (
            <>
              {/* Table on wide screens */}
              <div className="hidden overflow-x-auto rounded-lg border border-slate-200 md:block">
                <table className="w-full border-collapse text-left">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50">
                      {COLUMNS.map((column) => (
                        <th
                          key={column}
                          scope="col"
                          className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500"
                        >
                          {column}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {medications.map((medication) => (
                      <MedicationRow
                        key={medication.id}
                        medication={medication}
                        onRemove={removeMedication}
                        onRemarks={setRemarks}
                      />
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Stacked cards on a phone */}
              <div className="space-y-1.5 md:hidden">
                {medications.map((medication) => (
                  <MedicationCard
                    key={medication.id}
                    medication={medication}
                    onRemove={removeMedication}
                    onRemarks={setRemarks}
                  />
                ))}
              </div>
            </>
          )}
          <MedicationPicker onAdd={addMedication} />
        </Stack>
      </Panel>

      <Panel
        title="Cardioprotective therapy analysis"
        subtitle="Assessed against this patient's therapy, risk category and current findings"
      >
        {recommendations.length === 0 ? (
          <EmptyState>No cardioprotective therapy is triggered by the current findings.</EmptyState>
        ) : (
          <Stack gap="gap-2.5">
            {recommendations.map((recommendation) => {
              const decision = encounter.medDecisions?.[recommendation.id] || "";
              const belowTarget = recommendation.belowTarget || [];
              const toneName = recommendation.onTreatment
                ? belowTarget.length
                  ? "warning"
                  : "ok"
                : recommendation.strength === "Indicated"
                  ? "danger"
                  : "warning";
              return (
                <div
                  key={recommendation.id}
                  className={`rounded-xl border p-3.5 ${
                    recommendation.onTreatment
                      ? belowTarget.length
                        ? "border-amber-200 bg-amber-50/40"
                        : "border-emerald-200 bg-emerald-50/40"
                      : recommendation.strength === "Indicated"
                        ? "border-red-200 bg-red-50/40"
                        : "border-amber-200 bg-amber-50/30"
                  }`}
                >
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[14px] font-semibold text-slate-900">
                        {recommendation.title}
                      </span>
                      <StatusChip tone={toneName}>
                        {recommendation.onTreatment
                          ? belowTarget.length
                            ? "Prescribed, below target"
                            : "Already prescribed"
                          : recommendation.strength}
                      </StatusChip>
                    </div>
                    {recommendation.current && (
                      <span className="text-[12px] text-emerald-700">{recommendation.current}</span>
                    )}
                  </div>

                  {belowTarget.length > 0 && (
                    <div className="mb-2 rounded-lg border border-amber-200 bg-white/70 px-3 py-2">
                      <div className="text-[12px] font-medium uppercase tracking-wide text-amber-700">
                        Dose review (provisional)
                      </div>
                      <ul className="mt-1 space-y-0.5 pl-4 text-[13px] text-slate-700">
                        {belowTarget.map((dose) => (
                          <li key={dose.ingredientId} className="list-disc">
                            {dose.name} at {dose.dailyDose} {dose.unit}/day is {dose.percentOfTarget}%
                            of the {dose.target} {dose.unit} target
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="text-[12.5px] font-medium uppercase tracking-wide text-slate-400">
                    Why this is showing
                  </div>
                  <ul className="mt-1 space-y-1 pl-4 text-[13px] leading-relaxed text-slate-600">
                    {recommendation.reasons.map((reason) => (
                      <li key={reason} className="list-disc">{reason}</li>
                    ))}
                  </ul>

                  <p className="mt-2 text-[13px] leading-relaxed text-slate-700">
                    {recommendation.guidance}
                  </p>

                  {!recommendation.onTreatment && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Chip
                        size="sm"
                        tone="ok"
                        active={decision === "accepted"}
                        onClick={() => setDecision(recommendation.id, "accepted")}
                      >
                        Starting this
                      </Chip>
                      <Chip
                        size="sm"
                        tone="warning"
                        active={decision === "deferred"}
                        onClick={() => setDecision(recommendation.id, "deferred")}
                      >
                        Deferred
                      </Chip>
                      <Chip
                        size="sm"
                        tone="neutral"
                        active={decision === "declined"}
                        onClick={() => setDecision(recommendation.id, "declined")}
                      >
                        Not appropriate
                      </Chip>
                    </div>
                  )}
                </div>
              );
            })}
          </Stack>
        )}
      </Panel>

      <Panel title="Safety review" subtitle="Interaction, duplication, dose and QT screening across the full list">
        {warnings.length === 0 ? (
          <Callout tone="ok" title="No medication safety concerns detected">
            The current list shows no duplicate classes, QT-prolonging combinations, dose concerns or
            interaction risks against this therapy.
          </Callout>
        ) : (
          <Stack gap="gap-2">
            {warnings.map((warning) => {
              const Icon = WARNING_ICON[warning.level] || Info;
              return (
                <Callout key={warning.id} tone={warning.level} title={warning.title} icon={Icon}>
                  <span className="block">{warning.detail}</span>
                  <span className="mt-1 block text-[12px] italic text-slate-500">{warning.why}</span>
                </Callout>
              );
            })}
          </Stack>
        )}
      </Panel>

      <Panel title="Review note">
        <TextArea
          label="Medication review documentation"
          rows={3}
          placeholder="Changes made this visit, counselling given, adherence, monitoring arranged"
          value={encounter.medReview || ""}
          onChange={(value) => setEncounter((current) => ({ ...current, medReview: value }))}
        />
      </Panel>
    </Stack>
  );
}

export const MEDICATION_ICON = Pill;
