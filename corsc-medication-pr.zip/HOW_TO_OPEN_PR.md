# How to open this as a real pull request

I don't have push access to GitHub from this chat — no connector for it is
available right now — so this is the part that needs your hands. It's three
commands.

## 1. Apply the patch series to your local clone

From the root of your actual CORSC clone, on an up-to-date `main`
(swap in `master` if that's your default branch):

```bash
git checkout main
git pull
git checkout -b feature/medication-catalog-and-scheduling
git am /path/to/patches/0001-*.patch \
       /path/to/patches/0002-*.patch \
       /path/to/patches/0003-*.patch \
       /path/to/patches/0004-*.patch
```

`git am` preserves the four commit messages exactly as written. If any patch
fails to apply (only possible if `main` has moved since this repo export),
`git am --show-current-patch` shows what's conflicting — resolve, then
`git am --continue`.

## 2. Push and open the PR

```bash
git push -u origin feature/medication-catalog-and-scheduling
```

Then either open the PR on github.com (a "Compare & pull request" banner
will appear on the repo page) and paste in `PR_DESCRIPTION.md`, or, if you
have the `gh` CLI:

```bash
gh pr create --title "Add medication catalog, dosing schedule, and clinician-reviewed intake pipeline" \
             --body-file PR_DESCRIPTION.md \
             --base main
```

## 3. Before merging

Run the review export and get pharmacist sign-off — this is described in
detail in `PR_DESCRIPTION.md` under "Before this reaches a real patient":

```bash
node scripts/export-catalog-review.mjs
```

## About authorship

The four commits are attributed to `Claude (AI pair-programmer)
<noreply@localhost>` — a clearly synthetic identity so it's never confused
with your own commit history. Amend authorship however you want before
pushing, for instance:

```bash
git commit --amend --author="Your Name <you@example.com>" --no-edit
```

or add yourself as a co-author trailer to each commit message if you'd
rather keep mine visible alongside yours. Given the dual developer/investigator
role flagged in your IEC proposal, you may want the audit trail to show your
review explicitly either way — worth a moment's thought before this becomes
part of the permanent history.

## If you'd rather I push this directly

I don't currently have a GitHub connector available to search or connect.
If you set one up under Settings → Connectors, tell me the repo (owner/name)
and I can push this branch and open the PR through it directly next time,
rather than handing you patches.
