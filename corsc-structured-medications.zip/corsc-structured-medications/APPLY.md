# CORSC — structured six-column medication entry

Drop these files over the repo root preserving paths, or apply
`patches/0001-*.patch` with `git am` for a ready-made commit.

No new npm dependencies.

## The six columns

| # | Column | Type | Source |
|---|---|---|---|
| 1 | Drug name | Searchable dropdown | 386 brands, matches selling name, generic composition and misspellings |
| 2 | Dose | Dependent dropdown | Only strengths marketed under the selected brand |
| 3 | Route | Dropdown | PO, SL, PR, inhalation, nebulization, IM, IV, SC (+ ophthalmic, topical, nasal) |
| 4 | Frequency | Dropdown **or** 1-0-0-1 | Named options, or M-A-E-N pattern with fractions |
| 5 | Timing | Dropdown | Before food, after food, empty stomach, as directed |
| 6 | Remarks | Free text | Editable inline in the table |

### Dose is now a dependent dropdown

Previously "Rosuvas 10" and "Rosuvas 20" were unrelated catalogue entries. The
catalogue is now regrouped by brand, so selecting **Rosuvas** populates the dose
dropdown with 5 / 10 / 20 / 40 mg. Combination brands work the same way —
**Telma AM** offers 40/5, 40/10 and 80/5 mg.

### Fractional dosing

The 1-0-0-1 mode accepts quarter-tablet decimals, so half and double tablets are
documentable and feed the dose arithmetic correctly:

- Concor 10 mg at `0.5-0-0-0` → 5 mg/day, flagged below target
- Concor 10 mg at `1-0-0-1` → 20 mg/day, flagged above maximum

Named frequencies carry an equivalent pattern internally, so "Twice daily" and
`1-0-0-1` produce identical dose maths. SOS contributes zero daily dose and is
excluded from dose adequacy, as it should be.

## Route now gates systemic reasoning

**This is new clinical logic and needs your sign-off.** A drug only counts
towards systemic therapy when its route is systemic. Concretely: timolol eye
drops no longer register the patient as being on a beta-blocker, so the app
stops suppressing a genuinely needed heart-failure beta-blocker recommendation.

The same gate excludes non-systemic routes from QT burden, CYP3A4 interaction
and duplicate-class checks.

Caveat worth holding: ophthalmic beta-blockade *can* still cause systemic
bradycardia in susceptible patients. This gate governs treatment-decision logic,
not a claim that eye drops are systemically inert.

## Adding drugs not in the library

Typing an unknown drug offers **add to library**. The clinician records generic
composition, dose and class as free text. The entry saves to the patient
immediately either way; submission to the shared library happens only after
ticking a declaration that the text contains no patient identifiers. That
declaration is enforced in `submitCatalogRequest`, not just in the UI, so it
holds from any caller.

Reviewed entries land in `drug_catalog_requests` for promotion into
`drug_products`.

## On the CDSCO / MedPlus integration you mentioned

I did not wire one up, because as far as I know neither offers a public
machine-readable API — CDSCO publishes approval PDFs, and MedPlus has no
documented public endpoint. Rather than fabricate an integration against an API
I can't verify exists, the architecture leaves the hosted `drug_products` table
as the seam: if you obtain a licensed feed (or scrape one you have rights to),
it loads into that table and the picker picks it up with no client changes.
Worth verifying the current state of both before ruling it out.

## Deploy

1. `supabase db push` — the migration adds `composition` and `dose` columns to
   the review queue. Without it the hosted lookup is skipped and add-to-library
   reports the service unavailable; the bundled catalogue keeps working offline.
2. Deploy as usual.

## Before clinical use

```bash
node scripts/export-catalog-review.mjs
```

Writes `catalog-review/ingredients.csv` (287 rows) and `products.csv` (875
rows) with blank `reviewer_verdict` / `reviewer_comment` columns. These hold
every clinical assertion in the catalogue — class mappings, QT and CYP3A4
flags, dose bands, brand-to-molecule mappings — and are my best-effort
assertions, not verified data.

Confidence is uneven: cardiovascular, GI and diabetes entries are the most
cross-checked; oncology, dermatology and ophthalmology are thinner. Weight
review accordingly.

Dose-adequacy findings render as **provisional** in the UI until sign-off, and
apply only to ACE inhibitor / ARB / ARNI / beta-blocker / MRA.

## Migration of existing records

Legacy free-text entries are never rewritten in storage. They keep their
original text, gain `doseLabel` and `remarks` fields, are flagged
`needsReview: true`, and are matched against the catalogue only at read time —
surfaced in the table as "Matched from older record" so a clinician confirms
before the inference is relied on.
