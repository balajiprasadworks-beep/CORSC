"use client";

/* =========================================================================
   Medication table.

   Shared by medication history and medication review so both present the same
   six columns in the same order. Table on wide screens, stacked cards on a
   phone, where a six-column table would be unreadable.
   ========================================================================= */

import { Trash2 } from "lucide-react";

import { StatusChip, TextArea, mono } from "@/components/kit";
import { assessDose, medClassLabel, resolveMedication } from "@/lib/medication-engine";
import { describeIngredients } from "@/lib/drug-catalog";
import {
  frequencyText,
  routeLabel,
  timingLabel,
  normaliseSchedule,
  isSystemicRoute,
  isScheduleEmpty,
} from "@/lib/medication-schedule";

const DOSE_TONE = {
  atTarget: { tone: "ok", text: "At target" },
  belowTarget: { tone: "warning", text: "Below target" },
  aboveMax: { tone: "danger", text: "Above maximum" },
};

const COLUMNS = ["Drug name", "Dose", "Route", "Frequency", "Timing", "Remarks", ""];

/** Everything the row and card views both need. Not a hook — plain derivation. */
function rowData(medication) {
  const { ingredients, klasses, displayName, resolved, inferred } = resolveMedication(medication);
  const schedule = normaliseSchedule(medication.schedule);
  return {
    ingredients,
    klasses,
    displayName,
    resolved,
    inferred,
    schedule,
    doses: assessDose(medication).filter((dose) => dose.status !== "unknown"),
    composition: ingredients.length ? describeIngredients(ingredients) : medication.composition || "",
    nonSystemic: !isSystemicRoute(schedule.route),
  };
}

function DoseChips({ doses }) {
  if (!doses.length) return null;
  return (
    <div className="mt-1 flex flex-wrap gap-1">
      {doses.map((dose) => {
        const label = DOSE_TONE[dose.status];
        if (!label) return null;
        return (
          <StatusChip key={dose.ingredientId} tone={label.tone}>
            {dose.name} {dose.dailyDose} {dose.unit}/day — {label.text}
            {dose.status === "belowTarget" && dose.percentOfTarget !== null
              ? ` (${dose.percentOfTarget}%)`
              : ""}
          </StatusChip>
        );
      })}
    </div>
  );
}

function NameCell({ data }) {
  return (
    <div className="min-w-0">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-[13.5px] font-semibold text-slate-900">{data.displayName}</span>
        {!data.resolved && <StatusChip tone="warning">Unmatched</StatusChip>}
        {data.inferred && <StatusChip tone="warning">Matched from older record</StatusChip>}
      </div>
      {data.composition && <div className="mt-0.5 text-[12px] text-slate-500">{data.composition}</div>}
      <div className="mt-1 flex flex-wrap gap-1">
        {data.klasses.map((klass) => (
          <StatusChip key={klass} tone="neutral">{medClassLabel(klass)}</StatusChip>
        ))}
        {data.nonSystemic && <StatusChip tone="neutral">Not systemic</StatusChip>}
      </div>
    </div>
  );
}

function Card({ medication, onRemove, onRemarks, showDoseAdequacy }) {
  const data = rowData(medication);
  return (
    <div className="rounded-lg border border-slate-200 px-3 py-2.5">
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          <NameCell data={data} />
          <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[12.5px]">
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Dose</dt>
              <dd className="text-slate-700">{medication.doseLabel || "—"}</dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Route</dt>
              <dd className="text-slate-700">{routeLabel(data.schedule.route)}</dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Frequency</dt>
              <dd className="text-slate-700" style={mono}>
                {isScheduleEmpty(medication.schedule) ? "—" : frequencyText(data.schedule)}
              </dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-wide text-slate-400">Timing</dt>
              <dd className="text-slate-700">{timingLabel(data.schedule.timing)}</dd>
            </div>
          </dl>
          {showDoseAdequacy && <DoseChips doses={data.doses} />}
          <TextArea
            label="Remarks"
            rows={1}
            placeholder="Add a note"
            value={medication.remarks || ""}
            onChange={(value) => onRemarks(medication, value)}
          />
        </div>
        <button
          type="button"
          onClick={() => onRemove(medication)}
          aria-label={`Remove ${data.displayName}`}
          className="shrink-0 rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
        >
          <Trash2 size={15} aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

function Row({ medication, onRemove, onRemarks, showDoseAdequacy }) {
  const data = rowData(medication);
  return (
    <tr className="border-b border-slate-100 align-top last:border-b-0">
      <td className="px-3 py-2.5">
        <NameCell data={data} />
        {showDoseAdequacy && <DoseChips doses={data.doses} />}
      </td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700">{medication.doseLabel || "—"}</td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700">{routeLabel(data.schedule.route)}</td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700" style={mono}>
        {isScheduleEmpty(medication.schedule) ? "—" : frequencyText(data.schedule)}
      </td>
      <td className="px-3 py-2.5 text-[13px] text-slate-700">{timingLabel(data.schedule.timing)}</td>
      <td className="px-3 py-2.5">
        <TextArea
          label=""
          rows={2}
          placeholder="Add a note"
          value={medication.remarks || ""}
          onChange={(value) => onRemarks(medication, value)}
        />
      </td>
      <td className="px-2 py-2.5">
        <button
          type="button"
          onClick={() => onRemove(medication)}
          aria-label={`Remove ${data.displayName}`}
          className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
        >
          <Trash2 size={15} aria-hidden="true" />
        </button>
      </td>
    </tr>
  );
}

export function MedicationTable({ medications, onRemove, onRemarks, showDoseAdequacy = true }) {
  if (!medications?.length) return null;
  return (
    <>
      <div className="hidden overflow-x-auto rounded-lg border border-slate-200 md:block">
        <table className="w-full border-collapse text-left">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50">
              {COLUMNS.map((column, index) => (
                <th
                  key={column || `actions-${index}`}
                  scope="col"
                  className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500"
                >
                  {column}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {medications.map((medication) => (
              <Row
                key={medication.id}
                medication={medication}
                onRemove={onRemove}
                onRemarks={onRemarks}
                showDoseAdequacy={showDoseAdequacy}
              />
            ))}
          </tbody>
        </table>
      </div>

      <div className="space-y-1.5 md:hidden">
        {medications.map((medication) => (
          <Card
            key={medication.id}
            medication={medication}
            onRemove={onRemove}
            onRemarks={onRemarks}
            showDoseAdequacy={showDoseAdequacy}
          />
        ))}
      </div>
    </>
  );
}
